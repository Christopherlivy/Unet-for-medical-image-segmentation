import os 
#os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
from segmentation_models import Unet
import numpy as np
from keras.models import *
from keras.layers import Input, merge, Conv2D, MaxPooling2D, UpSampling2D, Dropout, Cropping2D
from keras.optimizers import *
from keras.layers import Concatenate
from keras.callbacks import ModelCheckpoint, LearningRateScheduler
from keras import backend as keras
from data import *



class myUnet(object):
	def __init__(self, img_rows = 64, img_cols = 64):
		self.img_rows = img_rows
		self.img_cols = img_cols
# 参数初始化定义
	def load_data(self):
		mydata = dataProcess(self.img_rows, self.img_cols)
		imgs_train, imgs_mask_train = mydata.load_train_data()
		imgs_test = mydata.load_test_data()
		return imgs_train, imgs_mask_train, imgs_test


	def train(self):
		print("loading data")
		imgs_train, imgs_mask_train, imgs_test = self.load_data()
		print("loading data done")
		#model = self.get_unet()
		model = Unet('resnet34', input_shape=(64, 64, 3), encoder_weights=None)
		model.compile('Adam', loss='binary_crossentropy', metrics=['accuracy'])
		#model = load_model("final_model")
		print("got unet")
		model_checkpoint = ModelCheckpoint('final_model', monitor='loss',verbose=1, save_best_only=True)
		print('Fitting model...')
		model.fit(imgs_train, imgs_mask_train, batch_size=16, nb_epoch=15, verbose=1,validation_split=0.2, shuffle=True,callbacks=[model_checkpoint])
		print('predict test data')
		imgs_mask_test = model.predict(imgs_test, batch_size=1, verbose=1)
		np.save('../results/imgs_mask_test.npy', imgs_mask_test)

	def save_img(self):
		print("array to image")
		imgs = np.load('../results/imgs_mask_test.npy')
		imgs[imgs>0.5]=1
		imgs[imgs<=0.5]=0
		for i in range(imgs.shape[0]):
			img = imgs[i]
			img = array_to_img(img)
			img.save("../results/%d.tif"%(i+1))

if __name__ == '__main__':
	myunet = myUnet()
	myunet.train()
	myunet.save_img()
